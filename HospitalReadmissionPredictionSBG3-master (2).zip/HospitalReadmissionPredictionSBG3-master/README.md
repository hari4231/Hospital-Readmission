# HospitalReadmissionPredictionSBG3
Hospital Readmission Prediction is a project that predicts whether the patient(s) readmits hospital or not.

Problem Statement and Objective 
The hospital readmission is when a patient who is discharged from the hospital, gets re-admitted again within a certain period of time. Hospital readmission rates for certain conditions are now considered an indicator of hospital quality, and also affect the cost of care adversely.
